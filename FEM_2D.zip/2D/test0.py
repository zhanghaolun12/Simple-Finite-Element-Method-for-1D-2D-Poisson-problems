import math
import time
import numpy as np
from numpy.core.defchararray import array, multiply
import os
from matplotlib import cm
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from numpy.core.function_base import linspace
from numpy.lib.function_base import meshgrid
from scipy import linalg


'''def f(x):
    result = np.multiply(np.exp(x),np.sin(x))
    return result

def fun(f,x):
    r=f(x)
    return r

def func(x):
    r1=x
    r2=x\
        +1
    x=x*10
    return r1,r2,x'''

def clear():
    os.system('cls')

if __name__ == '__main__':
    clear()
    a=np.array([[1,2,3],[4,5,6],[7,8,9]])
    b=np.zeros((4,4))
    c=np.array([1,2,3,4,5,6,7,8,9])
    d=np.arange(1,10+1,1)
    #a[:,[2]]=([[1],[2],[3]])
    #print('a=',a[:,[0,1,2]])
    #print(a.shape)
    #print(a[:,[2]])
    #print('b=',b)
    #print(c[c[2]])
    #print(d)
    #print(np.arange(5))
    #x=np.array([1,2,3,4,5])*np.pi
    #print(x)
    #y1=f(a[:,[2]])
    #print(y1)
    #y2=map(f,x)
    #print(list(y2))
    #y3=fun(f,x)
    #print(y3)
    #[r1,r2,y]=func(x)
    #print(r1)
    #print(r2)
    #print(x)
    #plt.loglog(x,y,'o-',x,r1,'s-',x,r2,'-^')
    #plt.xlabel('x')
    #plt.ylabel('y')
    #plt.title('solution')
    #plt.legend(['$\mathregular{L_{\infty}}$','$\mathregular{L_2}$','$\mathregular{H_1}$'])
    #plt.show()
    #print(np.square(x[1]))
    #A=np.array([[0.131973292606335,0.575208595078466,0.353158571222071],[0.942050590775485,0.0597795429471560,0.821194040197959],[0.956134540229802,0.234779913372406,0.0154034376515550]])
    #b=np.array([0.0430238016578078,0.168990029462704,0.649115474956452])
    #print(A)
    #print(b)
    #x=linalg.solve(A, b)
    #print(x)
    print(c+1)