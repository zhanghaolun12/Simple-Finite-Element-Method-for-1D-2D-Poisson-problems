# -*- coding: UTF-8 -*-

import math
import time
import numpy as np
from numpy.core.defchararray import array, multiply
import os
from matplotlib import cm
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from numpy.core.function_base import linspace
from numpy.lib.function_base import meshgrid
from scipy import linalg


## ========================定义方程类========================== ##
#包含方程的信息
class pde:

    def exact_solution(t,x,y):
        exact=np.exp(x+y+t)
        return exact

    def exact_solution_x_derivative(t,x,y):
        exact_x=np.exp(x+y+t)
        return exact_x

    def exact_solution_y_derivative(t,x,y):
        exact_y=np.exp(x+y+t)
        return exact_y

    def function_a(x,y):
        r_a=0
        return r_a

    def function_f(t,x,y):
        r_f=-3*np.exp(x+y+t)
        return r_f

    def function_g(t,x,y):
        r_g=np.exp(x+y+t)
        return r_g


def function_initial(x,y):
        r_init=np.exp(x+y)
        return r_init

def function_K11(x,y):
        r_K11=2
        return r_K11

def function_K12(x,y):
        r_K12=0
        return r_K12

def function_K21(x,y):
        r_K21=0
        return r_K21

def function_K22(x,y):
        r_K22=2
        return r_K22

def function_one(x,y):
        r_one=1
        return r_one

def get_initial_vector(initial_function_name,M_basis):
    row,col=M_basis.shape
    number_of_nodes=col
    r_init=np.zeros((number_of_nodes))
    for i in np.arange(number_of_nodes).astype(int):
        r_init[i]=initial_function_name(M_basis[0,i],M_basis[1,i])
    
    return r_init

def generate_Gauss_reference_triangle(Gauss_point_number):
    if Gauss_point_number==4:
        Gauss_coefficient_reference_triangle=np.array([(1-1/np.sqrt(3))/8,(1-1/np.sqrt(3))/8,(1+1/np.sqrt(3))/8,(1+1/np.sqrt(3))/8])
        Gauss_point_reference_triangle=np.array([[(1/np.sqrt(3)+1)/2,(1-1/np.sqrt(3))*(1+1/np.sqrt(3))/4],[(1/np.sqrt(3)+1)/2,(1-1/np.sqrt(3))*(1-1/np.sqrt(3))/4],[(-1/np.sqrt(3)+1)/2,(1+1/np.sqrt(3))*(1+1/np.sqrt(3))/4],[(-1/np.sqrt(3)+1)/2,(1+1/np.sqrt(3))*(1-1/np.sqrt(3))/4]])
    elif Gauss_point_number==9:
        Gauss_coefficient_reference_triangle=np.array([64/81*(1-0)/8,100/324*(1-np.sqrt(3/5))/8,100/324*(1-np.sqrt(3/5))/8,100/324*(1+np.sqrt(3/5))/8,100/324*(1+np.sqrt(3/5))/8,40/81*(1-0)/8,40/81*(1-0)/8,40/81*(1-np.sqrt(3/5))/8,40/81*(1+np.sqrt(3/5))/8])
        Gauss_point_reference_triangle=np.array([[(1+0)/2,(1-0)*(1+0)/4],[(1+np.sqrt(3/5))/2,(1-np.sqrt(3/5))*(1+np.sqrt(3/5))/4],[(1+np.sqrt(3/5))/2,(1-np.sqrt(3/5))*(1-np.sqrt(3/5))/4],[(1-np.sqrt(3/5))/2,(1+np.sqrt(3/5))*(1+np.sqrt(3/5))/4],[(1-np.sqrt(3/5))/2,(1+np.sqrt(3/5))*(1-np.sqrt(3/5))/4],[(1+0)/2,(1-0)*(1+np.sqrt(3/5))/4],[(1+0)/2,(1-0)*(1-np.sqrt(3/5))/4],[(1+np.sqrt(3/5))/2,(1-np.sqrt(3/5))*(1+0)/4],[(1-np.sqrt(3/5))/2,(1+np.sqrt(3/5))*(1+0)/4]])
    elif Gauss_point_number==3:
        Gauss_coefficient_reference_triangle=np.array([1/6,1/6,1/6])
        Gauss_point_reference_triangle=np.array([[1/2,0],[1/2,1/2],[0,1/2]])
    
    return Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle

def generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices_triangle):
    x1=vertices_triangle[0,0]
    y1=vertices_triangle[1,0]
    x2=vertices_triangle[0,1]
    y2=vertices_triangle[1,1]
    x3=vertices_triangle[0,2]
    y3=vertices_triangle[1,2]
    Jacobi=np.abs((x2-x1)*(y3-y1)-(x3-x1)*(y2-y1))
    Gauss_coefficient_local_triangle=Gauss_coefficient_reference_triangle*Jacobi
    Gauss_point_local_triangle=np.zeros(Gauss_point_reference_triangle.shape)
    Gauss_point_local_triangle[:,0]=x1+(x2-x1)*Gauss_point_reference_triangle[:,0]+(x3-x1)*Gauss_point_reference_triangle[:,1]
    Gauss_point_local_triangle[:,1]=y1+(y2-y1)*Gauss_point_reference_triangle[:,0]+(y3-y1)*Gauss_point_reference_triangle[:,1]

    return Gauss_coefficient_local_triangle,Gauss_point_local_triangle

def triangular_reference_basis(x,y,basis_type,basis_index,derivative_degree_x,derivative_degree_y):
    
    r_ref=0

    if basis_type==1:
    
        if derivative_degree_x==0 and derivative_degree_y==0:
        
            if basis_index==1:
                r_ref=-x-y+1
            elif basis_index==2:
                r_ref=x
            elif basis_index==3:
                r_ref=y
        
        elif derivative_degree_x==1 and derivative_degree_y==0:
        
            if basis_index==1:
                r_ref=-1
            elif basis_index==2:
                r_ref=1
            elif basis_index==3:
                r_ref=0
        
        elif derivative_degree_x==0 and derivative_degree_y==1:
        
            if basis_index==1:
                r_ref=-1
            elif basis_index==2:
                r_ref=0
            elif basis_index==3:
                r_ref=1
    
        elif derivative_degree_x+derivative_degree_y > 1:
        
            r_ref=0
    
    elif basis_type==2:
    
        if derivative_degree_x==0 and derivative_degree_y==0:
        
            if basis_index==1:
                r_ref=2*np.square(x)+2*np.square(y)+4*np.multiply(x,y)-3*y-3*x+1
            elif basis_index==2:
                r_ref=2*np.square(x)-x
            elif basis_index==3:
                r_ref=2*np.square(y)-y
            elif basis_index==4:
                r_ref=-4*np.square(x)-4*np.multiply(x,y)+4*x
            elif basis_index==5:
                r_ref=4*np.multiply(x,y)
            elif basis_index==6:
                r_ref=-4*np.square(y)-4*np.multiply(x,y)+4*y
        
        elif derivative_degree_x==1 and derivative_degree_y==0:
        
            if basis_index==1:
                r_ref=4*x+4*y-3
            elif basis_index==2:
                r_ref=4*x-1
            elif basis_index==3:
                r_ref=0
            elif basis_index==4:
                r_ref=-8*x-4*y+4
            elif basis_index==5:
                r_ref=4*y
            elif basis_index==6:
                r_ref=-4*y
        
        elif derivative_degree_x==0 and derivative_degree_y==1:
        
            if basis_index==1:
                r_ref=4*x+4*y-3
            elif basis_index==2:
                r_ref=0
            elif basis_index==3:
                r_ref=4*y-1
            elif basis_index==4:
                r_ref=-4*x
            elif basis_index==5:
                r_ref=4*x
            elif basis_index==6:
                r_ref=-8*y-4*x+4
        
        elif derivative_degree_x==2 and derivative_degree_y==0:
        
            if basis_index==1:
                r_ref=4
            elif basis_index==2:
                r_ref=4
            elif basis_index==3:
                r_ref=0
            elif basis_index==4:
                r_ref=-8
            elif basis_index==5:
                r_ref=0
            elif basis_index==6:
                r_ref=0
        
        elif derivative_degree_x==0 and derivative_degree_y==2:
        
            if basis_index==1:
                r_ref=4
            elif basis_index==2:
                r_ref=0
            elif basis_index==3:
                r_ref=4
            elif basis_index==4:
                r_ref=0
            elif basis_index==5:
                r_ref=0
            elif basis_index==6:
                r_ref=-8
        
        elif derivative_degree_x==1 and derivative_degree_y==1:
        
            if basis_index==1:
                r_ref=4
            elif basis_index==2:
                r_ref=0
            elif basis_index==3:
                r_ref=0
            elif basis_index==4:
                r_ref=-4
            elif basis_index==5:
                r_ref=4
            elif basis_index==6:
                r_ref=-4
        
        elif derivative_degree_x+derivative_degree_y > 2:
        
            r_ref=0

    return r_ref

def triangular_local_basis(x,y,vertices,basis_type,basis_index,derivative_degree_x,derivative_degree_y):
    J_11=vertices[0,1]-vertices[0,0]
    J_12=vertices[0,2]-vertices[0,0]
    J_21=vertices[1,1]-vertices[1,0]
    J_22=vertices[1,2]-vertices[1,0]
    J=np.array([[J_11,J_12],[J_21,J_22]])
    J_det=J_11*J_22 - J_12*J_21
    
    x_hat=(J_22*(x-vertices[0,0])-J_12*(y-vertices[1,0]))/J_det
    y_hat=(-J_21*(x-vertices[0,0])+J_11*(y-vertices[1,0]))/J_det

    if derivative_degree_x==0 and derivative_degree_y==0:
        r_local=triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,0,0)
    elif derivative_degree_x==1 and derivative_degree_y==0:
        r_local=(triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,1,0)*J_22+triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,0,1)*(-J_21))/J_det
    elif derivative_degree_x==0 and derivative_degree_y==1:
        r_local=(triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,1,0)*(-J_12)+triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,0,1)*J_11)/J_det
    elif derivative_degree_x==2 and derivative_degree_y==0:
        r_local=(triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,2,0)*np.square(J_22)+triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,0,2)*np.aquare(J_21)\
            +triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,1,1)*(-2*J_21*J_22))/np.square(J_det)
    elif derivative_degree_x==0 and derivative_degree_y==2:
        r_local=(triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,2,0)*np.square(J_12)+triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,0,2)*np.square(J_11)\
            +triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,1,1)*(-2*J_11*J_12))/np.square(J_det)
    elif derivative_degree_x==1 and derivative_degree_y==1:
        r_local=(triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,2,0)*(-J_22*J_12)+triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,0,2)*(-J_21*J_11)\
            +triangular_reference_basis(x_hat,y_hat,basis_type,basis_index,1,1)*(J_21*J_12+J_11*J_22))/np.square(J_det)

    return r_local

## 
def Gauss_quadrature_for_volume_integral_FE_solution_error_time_triangle(uh_local,accurate_function,checked_time,vertices,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,derivative_degree_x,derivative_degree_y):
    Gpn=len(Gauss_coefficient_reference_triangle)

    r_error=0
    [Gauss_coefficient_local_triangle,Gauss_point_local_triangle]=generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices)

    for i in np.arange(Gpn).astype(int):
        r_error=r_error+Gauss_coefficient_local_triangle[i]*np.square(accurate_function(checked_time,Gauss_point_local_triangle[i,0],Gauss_point_local_triangle[i,1])-FE_solution_triangle(Gauss_point_local_triangle[i,0],Gauss_point_local_triangle[i,1],uh_local,vertices,basis_type,derivative_degree_x,derivative_degree_y))

    return r_error


def Gauss_quadrature_for_volume_integral_test_time_triangle(coefficient_function_name,current_time,Gauss_coefficient_local,Gauss_point_local,vertices,test_basis_type,test_basis_index,test_derivative_degree_x,test_derivative_degree_y):
    Gpn=len(Gauss_coefficient_local)
    r_test=0
    for i in np.arange(Gpn).astype(int):
        r_test=r_test+Gauss_coefficient_local[i]*coefficient_function_name(current_time,Gauss_point_local[i,0],Gauss_point_local[i,1])*triangular_local_basis(Gauss_point_local[i,0],Gauss_point_local[i,1],vertices,test_basis_type,test_basis_index,test_derivative_degree_x,test_derivative_degree_y)

    return r_test

## Use Gauss quadrature to compute a volume integral on a local triangular element T for a matrix
def Gauss_quadrature_for_volume_integral_trial_test_triangle(coefficient_function_name,Gauss_coefficient_local,Gauss_point_local,vertices,trial_basis_type,trial_basis_index,trial_derivative_degree_x,trial_derivative_degree_y,test_basis_type,test_basis_index,test_derivative_degree_x,test_derivative_degree_y):
    Gpn=len(Gauss_coefficient_local)
    r_trial_test=0

    for i in np.arange(Gpn).astype(int):
        
        r_trial_test=r_trial_test+Gauss_coefficient_local[i]*coefficient_function_name(Gauss_point_local[i,0],Gauss_point_local[i,1])*triangular_local_basis(Gauss_point_local[i,0],Gauss_point_local[i,1],vertices,trial_basis_type,trial_basis_index,trial_derivative_degree_x,trial_derivative_degree_y)\
            *triangular_local_basis(Gauss_point_local[i,0],Gauss_point_local[i,1],vertices,test_basis_type,test_basis_index,test_derivative_degree_x,test_derivative_degree_y)

    return r_trial_test

## Assemble a matrix from a volume inegral on the whole domain with a triangular mesh.
def assemble_matrix_from_volume_integral_triangle(coefficient_function_name,M_partition,T_partition,T_basis_trial,T_basis_test,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,trial_basis_type,trial_derivative_degree_x,trial_derivative_degree_y,test_basis_type,test_derivative_degree_x,test_derivative_degree_y):
    r_matrix=np.zeros((matrix_size[0],matrix_size[1]))
    for n in np.arange(number_of_elements).astype(int):
        
        vertices=M_partition[:,T_partition[:,n]-1]
        [Gauss_coefficient_local_triangle,Gauss_point_local_triangle]=generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices)
        
        for alpha in np.arange(number_of_trial_local_basis).astype(int):

            for beta in np.arange(number_of_test_local_basis).astype(int):

                temp=Gauss_quadrature_for_volume_integral_trial_test_triangle(coefficient_function_name,Gauss_coefficient_local_triangle,Gauss_point_local_triangle,vertices,trial_basis_type,alpha+1,trial_derivative_degree_x,trial_derivative_degree_y,test_basis_type,beta+1,test_derivative_degree_x,test_derivative_degree_y)
                r_matrix[T_basis_test[beta,n]-1,T_basis_trial[alpha,n]-1]=r_matrix[T_basis_test[beta,n]-1,T_basis_trial[alpha,n]-1]+temp

    return r_matrix

## Assemble a vector from a volume inegral on the whole domain with a triangular mesh.
def assemble_vector_from_volume_integral_time_triangle(coefficient_function_name,current_time,M_partition,T_partition,T_basis_test,number_of_test_local_basis,number_of_elements,vector_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,test_basis_type,test_derivative_degree_x,test_derivative_degree_y):
    r_vector=np.zeros((vector_size))
    for n in np.arange(number_of_elements).astype(int):
        vertices=M_partition[:,T_partition[:,n]-1]
        [Gauss_coefficient_local_triangle,Gauss_point_local_triangle]=generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices)

        for beta in np.arange(number_of_test_local_basis).astype(int):
            temp=Gauss_quadrature_for_volume_integral_test_time_triangle(coefficient_function_name,current_time,Gauss_coefficient_local_triangle,Gauss_point_local_triangle,vertices,test_basis_type,beta+1,test_derivative_degree_x,test_derivative_degree_y)
            r_vector[T_basis_test[beta,n]-1]=r_vector[T_basis_test[beta,n]-1]+temp
    return r_vector

def generate_M_T_triangle(left,right,bottom,top,h_partition,basis_type):
    h1=h_partition[0]
    h2=h_partition[1]
    if basis_type == 1:
        N1=(right-left)/h1
        N2=(top-bottom)/h2
        N1=N1.astype(int)
        N2=N2.astype(int)
        M=np.zeros((2,(N1+1)*(N2+1)))
        T=np.zeros((3,2*N1*N2)).astype(int)
        k=0
        for i in np.arange(1,N1+2,1):
            x=left+(i-1)*h1
            for j in np.arange(1,N2+2,1):
                k=k+1
                y=bottom+(j-1)*h2
                M[:,k-1]=np.array([x,y])

        element=0
        for i in np.arange(1,N1+1,1):
            for j in np.arange(1,N2+1,1):
                k=(i-1)*(N2+1)+j
                T[:,element]=np.array([k,k+N2+1,k+1]).astype(int)
                T[:,element+1]=np.array([k+1,k+N2+1,k+N2+2]).astype(int)
                element=element+2
    elif basis_type == 2:
        N1=(right-left)/h1
        N2=(top-bottom)/h2
        N1=N1.astype(int)
        N2=N2.astype(int)
        dN1=2*N1
        dN2=2*N2
        dh1=h1/2
        dh2=h2/2
        M=np.zeros((2,(dN1+1)*(dN2+1)))
        T=np.zeros((6,2*N1*N2))

        k=0
        for i in np.arange(1,dN1+2,1):
            x=left+(i-1)*dh1
            for j in np.arange(1,dN2+2,1):
                k=k+1
                y=bottom+(j-1)*dh2
                M[:,k-1]=np.array([x,y])

        element=0
        for i in np.arange(1,N1+1,1):
            for j in np.arange(1,dN2,2):
                k=(i-1)*(2*(dN2+1))+j
                T[:,element]=np.array([k,k+2*(dN2+1),k+2,k+dN2+1,k+dN2+2,k+1]).astype(int)
                T[:,element+1]=np.array([k+2,k+2*(dN2+1),k+2*(dN2+1)+2,k+dN2+2,k+2*(dN2+1)+1,k+dN2+3]).astype(int)
                element=element+2

    return M,T.astype(int)

def get_2D_solution_and_maximum_error_time(checked_time,solution_1D,N1_basis,N2_basis,left,bottom,h_basis):
    maxerror=0
    solution_2D=np.zeros((N2_basis+1,N1_basis+1))

    for i in np.arange(N1_basis+1).astype(int):
        for j in np.arange(N2_basis+1).astype(int):
            solution_2D[j,i]=solution_1D[i*(N2_basis+1)+j]
            temp=solution_2D[j,i]-pde.exact_solution(checked_time,left+i*h_basis[0],bottom+j*h_basis[1])
            if np.abs(maxerror) < np.abs(temp):
                maxerror=temp

    return solution_2D,maxerror


def generate_boundary_nodes_edges(N1_basis,N2_basis,N1_partition,N2_partition):
    N1_basis=N1_basis.astype(int)
    N2_basis=N2_basis.astype(int)
    N1_partition=N1_partition.astype(int)
    N2_partition=N2_partition.astype(int)
    nbn=2*(N1_basis+N2_basis)
    
    boundary_nodes=np.zeros((2,nbn)).astype(int)
    k=-1

    for i in np.arange(1,N1_basis+1,1).astype(int):
        k=k+1
        boundary_nodes[0,k]=-1
        boundary_nodes[1,k]=1+(i-1)*(N2_basis+1)
    
    for j in np.arange(1,N2_basis+1,1).astype(int):
        k=k+1
        boundary_nodes[0,k]=-1
        boundary_nodes[1,k]=1+N1_basis*(N2_basis+1)+(j-1)

    for i in np.arange(1,N1_basis+1,1).astype(int):
        k=k+1
        boundary_nodes[0,k]=-1
        boundary_nodes[1,k]=1+N1_basis*(N2_basis+1)+N2_basis-(i-1)*(N2_basis+1)

    for j in np.arange(1,N2_basis+1,1).astype(int):
        k=k+1
        boundary_nodes[0,k]=-1
        boundary_nodes[1,k]=1+N1_basis*(N2_basis+1)+N2_basis-N1_basis*(N2_basis+1)-(j-1)

    nbe=2*(N1_partition+N2_partition)
    boundary_edges=np.zeros((4,nbe)).astype(int)
    k=-1

    for i in np.arange(1,N1_partition+1,1).astype(int):
        k=k+1
        boundary_edges[0,k]=-1
        boundary_edges[1,k]=1+2*N2_partition*(i-1)
        boundary_edges[2,k]=1+(N2_partition+1)*(i-1)
        boundary_edges[3,k]=1+(N2_partition+1)*i

    for j in np.arange(1,N2_partition+1,1).astype(int):
        k=k+1
        boundary_edges[0,k]=-1
        boundary_edges[1,k]=1+2*N2_partition*(N1_partition-1)+(2*j-1)
        boundary_edges[2,k]=1+(N2_partition+1)*N1_partition+(j-1)
        boundary_edges[3,k]=1+(N2_partition+1)*N1_partition+j

    for i in np.arange(1,N1_partition+1,1).astype(int):
        k=k+1
        boundary_edges[0,k]=-1
        boundary_edges[1,k]=2*N1_partition*N2_partition-2*N2_partition*(i-1)
        boundary_edges[2,k]=(N1_partition+1)*(N2_partition+1)-(N2_partition+1)*(i-1)
        boundary_edges[3,k]=(N1_partition+1)*(N2_partition+1)-(N2_partition+1)*i

    for j in np.arange(1,N2_partition+1,1).astype(int):
        k=k+1
        boundary_edges[0,k]=-1
        boundary_edges[1,k]=2*N2_partition-(2*j-1)
        boundary_edges[2,k]=N2_partition+1-(j-1)
        boundary_edges[3,k]=N2_partition+1-j

    return boundary_nodes,boundary_edges



def FE_solution_triangle(x,y,uh_local,vertices,basis_type,derivative_degree_x,derivative_degree_y):
    r_FE=0
    number_of_local_basis=len(uh_local)
    for i in np.arange(number_of_local_basis).astype(int):
        r_FE=r_FE+uh_local[i]*triangular_local_basis(x,y,vertices,basis_type,i+1,derivative_degree_x,derivative_degree_y)
    return r_FE

## Numerically compute the infinity norm error of FE solution on the whole domain [left,right]*[bottom,top]
def FE_solution_error_infinity_norm_time_triangle(uh,accurate_function,checked_time,left,right,bottom,top,h_partition,basis_type,derivative_degree_x,derivative_degree_y,Gauss_point_number):
    N1_partition=(right-left)/h_partition[0]
    N2_partition=(top-bottom)/h_partition[1]
    N1_partition=N1_partition.astype(int)
    N2_partition=N2_partition.astype(int)
    number_of_elements=2*N1_partition*N2_partition
    [M_partition,T_partition]=generate_M_T_triangle(left,right,bottom,top,h_partition,1)
    if basis_type==2:
        [M_basis,T_basis]=generate_M_T_triangle(left,right,bottom,top,h_partition,2)
    elif basis_type==1:
        T_basis=T_partition

    [Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle]=generate_Gauss_reference_triangle(Gauss_point_number)

    r_inf=0

    for n in np.arange(number_of_elements).astype(int):
        vertices=M_partition[:,T_partition[:,n]-1]
        uh_local=uh[T_basis[:,n]-1]
        [Gauss_coefficient_local_triangle,Gauss_point_local_triangle]=generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices)
        temp=np.max(np.abs(accurate_function(checked_time,Gauss_point_local_triangle[:,0],Gauss_point_local_triangle[:,1])-FE_solution_triangle(Gauss_point_local_triangle[:,0],Gauss_point_local_triangle[:,1],uh_local,vertices,basis_type,derivative_degree_x,derivative_degree_y)))
        if temp > r_inf:
            r_inf=temp

    return r_inf

def FE_solution_error_time_triangle(uh,accurate_function,checked_time,left,right,bottom,top,h_partition,basis_type,derivative_degree_x,derivative_degree_y,Gauss_point_number):
    N1_partition=(right-left)/h_partition[0]
    N2_partition=(top-bottom)/h_partition[1]
    N1_partition=N1_partition.astype(int)
    N2_partition=N2_partition.astype(int)
    number_of_elements=2*N1_partition*N2_partition

    [M_partition,T_partition]=generate_M_T_triangle(left,right,bottom,top,h_partition,1)
    if basis_type == 2:
        [M_basis,T_basis]=generate_M_T_triangle(left,right,bottom,top,h_partition,2)
    elif basis_type == 1:
        T_basis=T_partition
    
    [Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle]=generate_Gauss_reference_triangle(Gauss_point_number)

    r_error_tri=0

    for n in np.arange(number_of_elements).astype(int):
        vertices=M_partition[:,T_partition[:,n]-1]
        uh_local=uh[T_basis[:,n]-1]
        r_error_tri=r_error_tri+Gauss_quadrature_for_volume_integral_FE_solution_error_time_triangle(uh_local,accurate_function,checked_time,vertices,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,derivative_degree_x,derivative_degree_y)

    r_error_tri=np.sqrt(r_error_tri)
    return r_error_tri

def treat_Dirichlet_boundary_time_triangle(Dirichlet_boundary_function_name,current_time,A,b,boundary_nodes,M_basis):
    row,col=boundary_nodes.shape
    nbn=col

    for k in np.arange(nbn).astype(int):
        if boundary_nodes[0,k]==-1:
            i=boundary_nodes[1,k]
            A[i-1,:]=0
            A[i-1,i-1]=1
            b[i-1]=Dirichlet_boundary_function_name(current_time,M_basis[0,i-1],M_basis[1,i-1])

    return A,b

 ## ==============================二维热传导方程求解器================================ ##
def heat_solver_triangle(left,right,bottom,top,h_partition,basis_type,dt,initial_t,end_t,theta):
    N_t=(end_t-initial_t)/dt
    N_t=N_t.astype(int)
    N1_partition=(right-left)/h_partition[0]
    N2_partition=(top-bottom)/h_partition[1]
    N1_partition=N1_partition.astype(int)
    N2_partition=N2_partition.astype(int)
    ## 初始化变量
    N1_basis=N1_partition
    N2_basis=N2_partition
    T_basis=0
    number_of_trial_local_basis=0
    number_of_test_local_basis=0
    M_basis=0

    if basis_type == 2:
        N1_basis=N1_partition*2
        N2_basis=N2_partition*2
    elif basis_type == 1:
        N1_basis=N1_partition
        N2_basis=N2_partition

    [M_partition,T_partition]=generate_M_T_triangle(left,right,bottom,top,h_partition,1)

    if basis_type==2:
        [M_basis,T_basis]=generate_M_T_triangle(left,right,bottom,top,h_partition,2)
    elif basis_type==1:
        M_basis=M_partition
        T_basis=T_partition

    [Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle]=generate_Gauss_reference_triangle(9)

    number_of_elements=2*N1_partition*N2_partition
    
    #组装刚度矩阵
    matrix_size=np.array([(N1_basis+1)*(N2_basis+1),(N1_basis+1)*(N2_basis+1)]).astype(int)
    if basis_type==2:
        number_of_trial_local_basis=6
        number_of_test_local_basis=6
    elif basis_type==1:
        number_of_trial_local_basis=3
        number_of_test_local_basis=3

    A1=assemble_matrix_from_volume_integral_triangle(function_K11,M_partition,T_partition,T_basis,T_basis,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,1,0,basis_type,1,0)
    A2=assemble_matrix_from_volume_integral_triangle(function_K22,M_partition,T_partition,T_basis,T_basis,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,0,1,basis_type,0,1)
    A3=assemble_matrix_from_volume_integral_triangle(function_K12,M_partition,T_partition,T_basis,T_basis,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,0,1,basis_type,1,0)
    A4=assemble_matrix_from_volume_integral_triangle(function_K21,M_partition,T_partition,T_basis,T_basis,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,1,0,basis_type,0,1)
    A5=assemble_matrix_from_volume_integral_triangle(pde.function_a,M_partition,T_partition,T_basis,T_basis,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,0,0,basis_type,0,0)
    A=A1+A2+A3+A4+A5
    
    # 组装质量矩阵.
    M=assemble_matrix_from_volume_integral_triangle(function_one,M_partition,T_partition,T_basis,T_basis,number_of_trial_local_basis,number_of_test_local_basis,number_of_elements,matrix_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,0,0,basis_type,0,0)
    
    #生成边界点/边信息矩阵
    [boundary_nodes,boundary_edges]=generate_boundary_nodes_edges(N1_basis,N2_basis,N1_partition,N2_partition)

    A_fixed=M/dt+theta*A
    
    # Initialize the iteration in time.
    X_old=get_initial_vector(function_initial,M_basis)
    
    for n in np.arange(N_t).astype(int):
        current_time=initial_t+dt*(n+1)
        vector_size=(N1_basis+1)*(N2_basis+1)
        b1=assemble_vector_from_volume_integral_time_triangle(pde.function_f,current_time,M_partition,T_partition,T_basis,number_of_test_local_basis,number_of_elements,vector_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,0,0)
        b2=assemble_vector_from_volume_integral_time_triangle(pde.function_f,current_time-dt,M_partition,T_partition,T_basis,number_of_test_local_basis,number_of_elements,vector_size,Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,basis_type,0,0)
        b=theta*b1+(1-theta)*b2
        
        b=b+np.dot(M,X_old/dt)-(1-theta)*np.dot(A,X_old)

        #处理边界条件
        [A_fixed,b]=treat_Dirichlet_boundary_time_triangle(pde.function_g,current_time,A_fixed,b,boundary_nodes,M_basis)

        #求解线性方程组
        X=linalg.solve(A_fixed, b)

        X_old=X

        r=X

        if basis_type==2:
            h_basis=h_partition/2
        elif basis_type==1:
            h_basis=h_partition

        if n+1 == N_t:
            [solution_2D,maxerror]=get_2D_solution_and_maximum_error_time(end_t,X,N1_basis,N2_basis,left,bottom,h_basis)
            maximum_error_at_all_nodes_of_FE=maxerror
    
    return r,solution_2D,M_basis,T_basis,A,b

# ==================主函数==================== #
def main():
    #基函数类型:1表示线性基函数，2表示二次基函数
    basis_type = 1
    #求解区域:[left,right]×[bottom,top]
    left = 0
    right = 2
    bottom = 0
    top = 1

    #The time frame
    initial_t=0
    end_t=1

    #高斯点个数
    Gauss_point_number = 9

    theta=0.5

    ## ==================================================== ##
    #网格剖分步长
    h_partition = np.array([1/pow(2,4),1/pow(2,4)])
    dt = 0.01
    #有限元求解
    [uh,uh_2D,Pb,Tb,A,b]=heat_solver_triangle(left,right,bottom,top,h_partition,basis_type,dt,initial_t,end_t,theta)
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\solution.txt",uh)
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\solution_2D.txt",uh_2D)
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\A.txt", A)
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\b.txt", b)
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\Pb.txt",Pb)
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\Tb.txt",Tb)
    #计算误差
    infinity_error=FE_solution_error_infinity_norm_time_triangle(uh,pde.exact_solution,end_t,left,right,bottom,top,h_partition,basis_type,0,0,Gauss_point_number)
    L2_error=FE_solution_error_time_triangle(uh,pde.exact_solution,end_t,left,right,bottom,top,h_partition,basis_type,0,0,Gauss_point_number)
    H1_error_x=FE_solution_error_time_triangle(uh,pde.exact_solution_x_derivative,end_t,left,right,bottom,top,h_partition,basis_type,1,0,Gauss_point_number)
    H1_error_y=FE_solution_error_time_triangle(uh,pde.exact_solution_y_derivative,end_t,left,right,bottom,top,h_partition,basis_type,0,1,Gauss_point_number)
    H1_error=np.sqrt(np.square(H1_error_x)+np.square(H1_error_y))
    N = (1/h_partition[0]).astype(int) 
    print('h      infinity_error      L2_error       H1_error')
    print('1/%d  '%N,'  %e'%infinity_error,'   %e'%L2_error,'   %e'%H1_error)

    ## ===画图=== ##
    ## 真解
    fig1 = plt.figure()  
    ax1 = fig1.gca(projection='3d')
    #定义三维数据
    xx = Pb[0,:]
    yy = Pb[1,:]
    xx.shape=uh_2D.shape
    yy.shape=uh_2D.shape
    X = xx
    Y = yy
    u = pde.exact_solution(X,Y) #真解
    np.savetxt("F:\\Program\\python_code\\Finite_Element_Method\\2D\\exact.txt",u)
    #作图
    ax1.plot_surface(X,Y,u,cmap='rainbow',linewidth=0.5, edgecolors='k')
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('u')
    ax1.set_title('the exact solution')

    ## 有限元解
    fig2 = plt.figure()
    ax2 = fig2.gca(projection='3d')

    ax2.plot_surface(X,Y,uh_2D,cmap='rainbow',linewidth=0.5, edgecolors='k')
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.set_zlabel('u_h')
    ax2.set_title('the FE solution')
    plt.show()

    ## ===================计算不同步长的误差===================== ##
    '''print('h      dt     infinity_error     L2_error        H1_error')
    j = 0
    number = 5 #循环次数
    N = np.zeros((number)).astype(int)
    N_t = np.zeros((number)).astype(int)
    inf_err = np.zeros((number))
    L2_err = np.zeros((number))
    H1_err = np.zeros((number))
    for i in np.arange(2,2+number,1):
        h_partition=np.array([1/pow(2,i),1/pow(2,i)])
        dt=h_partition[0]
        N[j] = (1/h_partition[0]).astype(int)
        N_t[j] = (1/dt).astype(int)
        [uh,uh_2D,Pb,Tb,A,b]=heat_solver_triangle(left,right,bottom,top,h_partition,basis_type,dt,initial_t,end_t,theta)
        infinity_error=FE_solution_error_infinity_norm_time_triangle(uh,pde.exact_solution,end_t,left,right,bottom,top,h_partition,basis_type,0,0,Gauss_point_number)
        inf_err[j]=infinity_error
        L2_error=FE_solution_error_time_triangle(uh,pde.exact_solution,end_t,left,right,bottom,top,h_partition,basis_type,0,0,Gauss_point_number)
        L2_err[j]=L2_error
        H1_error_x=FE_solution_error_time_triangle(uh,pde.exact_solution_x_derivative,end_t,left,right,bottom,top,h_partition,basis_type,1,0,Gauss_point_number)
        H1_error_y=FE_solution_error_time_triangle(uh,pde.exact_solution_y_derivative,end_t,left,right,bottom,top,h_partition,basis_type,0,1,Gauss_point_number)
        H1_error=np.sqrt(np.square(H1_error_x)+np.square(H1_error_y))
        H1_err[j]=H1_error
        print('1/%d  '%N[j],'1/%d   '%N_t[j],'  %e'%infinity_error,'   %e'%L2_error,'   %e'%H1_error)
        j = j + 1
    
    R_inf_err = np.zeros((number-1))
    R_L2_err = np.zeros((number-1))
    R_H1_err = np.zeros((number-1))
    print('infinity_order  L2_order    H1_order')
    for i in np.arange(1,number,1):
        R_inf_err[i-1]=np.log(inf_err[i-1]/inf_err[i])/np.log(2)
        R_L2_err[i-1]=np.log(L2_err[i-1]/L2_err[i])/np.log(2)
        R_H1_err[i-1]=np.log(H1_err[i-1]/H1_err[i])/np.log(2)
        print('%f     '%R_inf_err[i-1],' %f   '%R_L2_err[i-1],'%f'%R_H1_err[i-1])

    h=[1/N[j] for j in np.arange(number).astype(int)]
    plt.loglog(h,inf_err,'o-',h,L2_err,'s-',h,H1_err,'-^',[1/10,1/20],[pow(10,-3),0.25*pow(10,-3)],'--',[1/10,1/20],[24*pow(10,-3),12*pow(10,-3)])
    plt.xlabel('log(h)')
    plt.ylabel('log(error)')
    plt.title('the numerical error of FEM')
    plt.legend(['$\mathregular{L_{\infty}}$','$\mathregular{L_2}$','$\mathregular{H_1}$','$O(h^2)$','$O(h)$'])
    plt.show()'''


def clear():
    os.system('cls')

if __name__ == '__main__':
    clear() #清屏
    main()  #调用主函数


