import numpy as np
from numpy.core.defchararray import array, multiply
import os
from matplotlib import cm
import matplotlib.pyplot as plt
from numpy.core.function_base import linspace
from numpy.lib.function_base import meshgrid
from scipy import linalg


class pde:

    def exact_solution(x,y):
        exact=np.exp(x+y)
        return exact

    def exact_solution_x_derivative(x,y):
        exact_x=np.exp(x+y)
        return exact_x

    def exact_solution_y_derivative(x,y):
        exact_y=np.exp(x+y)
        return exact_y

    def function_a(x,y):
        r_a=1
        return r_a

    def function_f(x,y):
        r_f=-2*np.exp(x+y)
        return r_f

    def function_g(x,y):
        r_g=np.exp(x+y)
        return r_g

if __name__ == '__main__':
    x=np.arange(0,1,0.01)
    y=np.arange(0,1,0.01)
    print(pde.exact_solution(x,y))